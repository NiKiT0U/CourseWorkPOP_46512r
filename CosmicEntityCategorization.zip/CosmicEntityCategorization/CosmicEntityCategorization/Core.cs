﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using CosmicEntityCategorization.CosmicEntitiesModels;

namespace CosmicEntityCategorization
{
    class Core
    {
        static Dictionary<string, Galaxy> allGalaxies = new Dictionary<string, Galaxy>();
        static Dictionary<string, Star> allStars = new Dictionary<string, Star>();
        static Dictionary<string, Planet> allPlanets = new Dictionary<string, Planet>();
        static Dictionary<string, Moon> allMoons = new Dictionary<string, Moon>();

        // related unities collections
        // Key - Galaxy's title, Value - Collection stars, that are related to.
        static Dictionary<string, List<Star>> starsMappedToGalaxy = new Dictionary<string, List<Star>>();
        // Key - Star's title, Value - Collection planets, that are related to.
        static Dictionary<string, List<Planet>> planetsMappedToStar = new Dictionary<string, List<Planet>>();
        // Key - Planet's title, Value - Collection moons, which are related to.
        static Dictionary<string, List<Moon>> moonsMappedToPlanet = new Dictionary<string, List<Moon>>();


        static void Main()
        {
            bool shouldIterate = true; 
            while(shouldIterate)
            {
                string command = Console.ReadLine();
                string commandResult = String.Empty;
                try
                {
                    MatchCollection matches = Regex.Matches(command, @"\[([\w \d]+)\]", RegexOptions.IgnoreCase);
                    string[] names = matches.Select(match => match.Groups[0].Value).ToArray();

                    foreach (string name in names)
                    {
                        command = command.Replace(name, String.Empty);
                    }

                    command = Regex.Replace(command, @"[ ]{2,}", String.Empty).Trim();
                    Console.WriteLine(names[0]);

                    string[] tokens = command.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    string commandName = tokens[0];
                    switch (commandName)
                    {
                        case "print": commandResult = PrintGalaxy(allGalaxies, names[0]); break;
                        case "stats": commandResult = Stats(allGalaxies.Count, allStars.Count, allPlanets.Count, allMoons.Count); break;
                        case "exit": shouldIterate = false; break;
                    }

                    commandName = $"{tokens[0]} {tokens[1]}";
                    switch (commandName)
                    {
                        case "add galaxy": AddGalaxy(names[0], tokens[2], tokens[3]); break;
                        case "add star": AddStar(names[0], names[1], double.Parse(tokens[2]), double.Parse(tokens[3]), int.Parse(tokens[4]), double.Parse(tokens[5])); break;
                        case "add//lanet": AddPlanet(names[0], names[1], tokens[2], bool.Parse(tokens[3])); break;
                        case "add moon": AddMoon(names[0], names[1]); break;
                        case "list galaxies": commandResult = ListEntityObjects(new List<CosmicEntity>(allGalaxies.Values), "galaxies");break;
                        case "list planets": commandResult = ListEntityObjects(new List<CosmicEntity>(allPlanets.Values), "planets"); break;
                        case "list stars": commandResult = ListEntityObjects(new List<CosmicEntity>(allStars.Values), "stars"); break;
                        case "list moons": commandResult = ListEntityObjects(new List<CosmicEntity>(allMoons.Values), "moons"); break;
                    }
                }
                catch (Exception ex)
                {
                    // commandResult = "none";
                    commandResult = ex.Message; 
                }
                finally
                {
                    if (commandResult != String.Empty)
                    {
                        Console.WriteLine(commandResult);
                    }
                }
            }
        }

        static void AddGalaxy(string name, string type, string age)
        {
            if (allGalaxies.ContainsKey(name))
            {
                throw new InvalidOperationException("The galaxy already exists.");
            }

            Galaxy createdGalaxy = new Galaxy(name, type, age);
            allGalaxies.Add(name, createdGalaxy);
            starsMappedToGalaxy.Add(name, new List<Star>());
        }

        static void AddStar(string galaxyName, string name, double mass, double size, int temp, double luminosity)
        {
            if (!allGalaxies.ContainsKey(galaxyName))
            {
                throw new InvalidOperationException("The galaxy doesn't exists.");
            }

            if (allStars.ContainsKey(name))
            {
                throw new InvalidOperationException("The star already exists.");
            }

            Star createdStar = new Star(name, mass, size, temp, luminosity);
            allStars.Add(name, createdStar);
            planetsMappedToStar.Add(name, new List<Planet>());
            starsMappedToGalaxy[galaxyName].Add(createdStar);
            
        }

        static void AddPlanet(string starName, string name, string type, bool supportedLife)
        {
            if (!allStars.ContainsKey(starName))
            {
                throw new InvalidOperationException("The star doesn't exists.");
            }

            if (allPlanets.ContainsKey(name))
            {
                throw new InvalidOperationException("The planet already exists.");
            }

            Planet createdPlanet = new Planet(name, type, supportedLife);
            allPlanets.Add(name, createdPlanet);
            moonsMappedToPlanet.Add(name, new List<Moon>());
            planetsMappedToStar[starName].Add(createdPlanet);
        }

        static void AddMoon(string planetName, string name)
        {
            if (!allPlanets.ContainsKey(planetName))
            {
                throw new InvalidOperationException("The planet doesn't exists.");
            }

            if (allMoons.ContainsKey(name))
            {
                throw new InvalidOperationException("The moon already exists.");
            }

            Moon createdMoon = new Moon(name);
            allMoons.Add(name, createdMoon);
            moonsMappedToPlanet[planetName].Add(createdMoon);
        }

        static string ListEntityObjects(List<CosmicEntity> entityValues, string entityTitle)
        {
            var namesCollection = entityValues.Select(x => x.Name);
            string result = $"--- List of all researched {entityTitle} ---\n{String.Join(", ", namesCollection)}";
            return result;
        }

        static string Stats(int galaxiesCount, int starsCount, int planetsCount, int moonsCount)
        {
            string result = "--- Stats ----";
            result += $"Galaxies: ${galaxiesCount}\n";
            result += $"Stars: ${starsCount}\n";
            result += $"Planets: ${planetsCount}\n";
            result += $"Moons: ${moonsCount}\n";
            result += "--- End of stats ----";
            return result;
        }

        static string PrintGalaxy(Dictionary<string, Galaxy> allGalaxies, string searchedGalaxy)
        {
            if(!allGalaxies.ContainsKey(searchedGalaxy))
            {
                throw new ArgumentException("The searched galaxy for printing was not found.");
            }

            string result = $"--- Data for {searchedGalaxy} galaxy ----\n";
            result += $"Galaxies: ${allGalaxies.Count}\n";
            result += $"Stars: ${allStars.Count}\n";
            result += $"Planets: ${allPlanets.Count}\n";
            result += $"Moons: ${allMoons.Count}\n";
            result += $"--- End of data for {searchedGalaxy} galaxy ----";
            return result;
        }
    }
}
