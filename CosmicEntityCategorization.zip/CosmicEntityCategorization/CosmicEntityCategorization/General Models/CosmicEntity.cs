﻿using System;
namespace CosmicEntityCategorization
{
    public abstract class CosmicEntity
    {
        private string name;

        public string Name{ get { return this.name; } set { this.name = value; } }

        public CosmicEntity(string name)
        {
            this.Name = name;
        }
    }
}
