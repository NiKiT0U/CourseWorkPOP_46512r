﻿using System;

namespace CosmicEntityCategorization
{
    abstract public class TypedCosmicEntity: CosmicEntity
    {
        protected string type;
        public abstract string Type { get; set; }

        public TypedCosmicEntity(string name, string type)
            : base(name)
        {
            this.Type = type;
        }

    }
}
