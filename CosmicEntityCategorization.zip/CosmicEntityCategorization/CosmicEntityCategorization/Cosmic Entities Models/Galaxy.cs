﻿using System;
using System.Collections.Generic;

namespace CosmicEntityCategorization.CosmicEntitiesModels
{
    public class Galaxy : TypedCosmicEntity
    {
        static List<string> AvailableTypes = new List<string> { "elliptical", "spiral", "Irregular" };

        private string age;

        public Galaxy(string name, string type, string age)
            : base(name, type)
        {
            this.Age = age;
        }

        public string Age
        {
            get { return this.age; }
            set
            {
                string ageAsString = value.Substring(0, value.Length - 1);
                char ageSuffix = value[value.Length - 1];
                if (ageSuffix != 'B' && ageSuffix !='M')
                {
                    throw new ArgumentException("The age identifier should be 'B' or 'M'");
                }


                if (double.TryParse(ageAsString, out double parsedAge))
                {
                    this.age = value;
                }
                else
                {
                    throw new ArgumentException("The number part for age is invalid.");
                }
            }
        }

        public override string Type
        {
            get { return this.type; }
            set
            {
                if (!Galaxy.AvailableTypes.Contains(value))
                {
                    throw new ArgumentOutOfRangeException($"{value} is invalid planet type.");
                }
            }
        }
    }
}