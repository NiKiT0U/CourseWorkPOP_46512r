﻿using System;
using System.Collections.Generic;

namespace CosmicEntityCategorization.CosmicEntitiesModels
{
    public class Planet : TypedCosmicEntity
    {
        static List<string> AvailableTypes = new List<string> { "terrestrial", "giant planet", "ice giant", "mesoplanet", "mini-neptune", "planter", "super-earth", "super-jupiter", "sub-earth" };

        private bool supportLife;

        public Planet(string name, string type, bool supportLife)
            : base(name, type)
        {
            this.SupportLife = supportLife;
        }

        public bool SupportLife
        {
            get { return this.supportLife; }
            set { this.supportLife = value; }
        }

        public override string Type
        {
            get { return this.type; }
            set
            {
                if (!Planet.AvailableTypes.Contains(value))
                {
                    throw new ArgumentOutOfRangeException($"{value} is invalid planet type.");
                }
            }
        }
    }
}
