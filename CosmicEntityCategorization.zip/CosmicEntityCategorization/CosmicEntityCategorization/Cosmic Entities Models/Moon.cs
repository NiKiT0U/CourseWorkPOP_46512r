﻿using System;
namespace CosmicEntityCategorization.CosmicEntitiesModels
{
    public class Moon: CosmicEntity
    {
        public Moon(string name)
            : base(name)
        {
        }
    }
}
