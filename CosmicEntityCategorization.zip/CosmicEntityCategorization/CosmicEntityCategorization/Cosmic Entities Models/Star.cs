﻿using System;
namespace CosmicEntityCategorization.CosmicEntitiesModels
{
    public class Star: CosmicEntity
    {
        private double mass;
        private double size;
        private int temp;
        private double luminosity;


        public Star(string name, double mass, double size, int temp, double luminosity)
            : base(name)
        {
            this.Mass = mass;
            this.Size = size;
            this.Temp = temp;
            this.Luminosity = luminosity;
        }

        public double Mass
        {
            get
            {
                return this.mass;
            }
            set
            {
                if (value < 0.08)
                {
                    throw new ArgumentOutOfRangeException($"Mass should be at least 0.08");
                }

                this.mass = value;
            }
        }

        public double Size
        {
            get { return this.size; }
            set { this.size = value; }
        }

        public int Temp
        {
            get
            {
                return this.temp;
            }
            set
            {
                if (value < 2400)
                {
                    throw new ArgumentOutOfRangeException($"Mass should be at least 0.08");
                }

                this.temp = value;
            }
        }

        public double Luminosity
        {
            get { return this.luminosity; }
            set { this.luminosity = value; }
        }

        public char Class
        {
            get
            {
                if(this.Temp >= 30000 && this.Luminosity >= 30000 && this.Mass >= 16 && this.Size >= 6.6)
                {
                    return 'O';
                }
                else if ((this.Temp > 10000 && this.Temp < 30000) &&
                    (this.Luminosity > 25 && this.Luminosity < 30000) &&
                    (this.Mass > 2.1 && this.Mass < 16 ) &&
                    (this.Size > 1.8 && this.Size < 6.6))
                {
                    return 'B';
                }
                else if ((this.Temp > 7500 && this.Temp <= 10000) &&
                    (this.Luminosity > 5 && this.Luminosity <= 25) &&
                    (this.Mass > 1.4 && this.Mass <= 2.1) &&
                    (this.Size > 1.8 && this.Size <= 6.6))
                {
                    return 'A';
                }
                else if ((this.Temp > 6000 && this.Temp <= 7500) &&
                    (this.Luminosity > 1.5 && this.Luminosity <= 5) &&
                    (this.Mass > 1.04 && this.Mass <= 1.4) &&
                    (this.Size > 1.15 && this.Size <= 1.4))
                {
                    return 'F';
                }
                else if ((this.Temp > 5200 && this.Temp <= 6000) &&
                    (this.Luminosity > 0.6 && this.Luminosity <= 1.5) &&
                    (this.Mass > 0.8 && this.Mass <= 1.04) &&
                    (this.Size > 0.96 && this.Size <= 1.15))
                {
                    return 'G';
                }
                else if ((this.Temp > 3700 && this.Temp <= 5200) &&
                    (this.Luminosity > 0.08 && this.Luminosity <= 0.6) &&
                    (this.Mass > 0.45 && this.Mass <= 0.8) &&
                    (this.Size > 0.7 && this.Size <= 0.96))
                {
                    return 'K';
                }
                else if ((this.Temp > 2400 && this.Temp <= 3700) &&
                   this.Luminosity <= 0.08 &&
                   this.Mass > 0.08 && this.Mass <= 0.45 &&
                   this.Size <= 0.7)
                {
                    return 'M';
                }

                throw new ArgumentException("Calculation of the class has failed, because of invalid star's properties.");
            }
        }
    }
}
